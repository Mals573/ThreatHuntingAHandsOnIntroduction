# Chrome Issue 1053604 JSCreate Side-Effect Type Confusion RCE Exploit

This script exploits a type confusion issue in Google Chrome. Tested on Windows 10 x64, Chrome version 80.0.3987.116.

* Start chrome with the --no-sandbox argument
* Running the exploit requires hosting the contents of this directory and visiting `exp.html` in Chrome. Shellcode can be replaced by modifying  the `shellcode.js` file. Currently shellcode length is limited to 4KiB.